<!-- chartist CSS -->
<link href="{{asset('super_admin')}}/assets/node_modules/morrisjs/morris.css" rel="stylesheet">
<!--Toaster Popup message CSS -->
<link href="{{asset('super_admin')}}/assets/node_modules/toast-master/css/jquery.toast.css" rel="stylesheet">
<link rel="stylesheet" type="text/css"
      href="{{asset('super_admin')}}/assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css">
<link rel="stylesheet" type="text/css"
      href="{{asset('super_admin')}}/assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<!-- Custom CSS -->
<link href="{{asset('super_admin')}}/assets/dist/css/style.min.css" rel="stylesheet">
<link href="{{asset('super_admin')}}/assets/dist/css/pages/tab-page.css" rel="stylesheet">
<!-- Dashboard 1 Page CSS -->
<link href="{{asset('super_admin')}}/assets/dist/css/pages/dashboard1.css" rel="stylesheet">
<link href="{{asset('super_admin')}}/assets/node_modules/icheck/skins/all.css" rel="stylesheet">
<link href="{{asset('super_admin')}}/assets/dist/css/pages/form-icheck.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" type="text/css" />
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->



{{-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/datetime/1.5.1/css/dataTables.dateTime.min.css"> --}}

<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">


<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.2/axios.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

{{-- boxicon --}}
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

{{-- fontawesome --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
